<?php
// Shortcode to display booking form
function mab_booking_form() {
    ob_start(); ?>
    
    <form method="post">
        <?php wp_nonce_field('mab_booking_nonce', 'mab_nonce'); ?>
        
        <p><label>Name:</label>
        <input type="text" name="mab_name" required></p>
        
        <p><label>Email:</label>
        <input type="email" name="mab_email" required></p>
        
        <p><label>Phone:</label>
        <input type="text" name="mab_phone" required></p>
        
        <p><label>Date:</label>
        <input type="date" name="mab_date" required></p>
        
        <p><label>Time:</label>
        <input type="time" name="mab_time" required></p>
        
        <p><button type="submit" name="mab_submit">Book Appointment</button></p>
    </form>
    
    <?php
    return ob_get_clean();
}
add_shortcode('mini_booking', 'mab_booking_form');
