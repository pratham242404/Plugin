<?php
/*
Plugin Name: Mini Appointment Booking
Plugin URI: https://check.local
Description: A lightweight appointment booking plugin.
Version: 1.0
Author: Prathamesh
Author URI: https://check.local
License: GPL2
*/

// Prevent direct access
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

// Include main plugin file
require_once plugin_dir_path(__FILE__) . 'includes/mini-booking-core.php';
